﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor1
{

    class Studetn
    {
        int rollno;
        //string firstname;
        //string lastname;
        //int standard;
    }

    class Program
    {
        //public Program()
        //{
        //    Console.WriteLine("hello C#");
        //}
        //public Program(int a, int b)
        //{

        //    Console.WriteLine("hello .net {0}", (a + b));
        //}
        //public Program(int a, int b , int c)
        //{

        //    Console.WriteLine("hello asp.net {0}", (a + b + c));
        //}

        static void Main(string[] args)
        {
            //Program p = new Program(20,30,32);

            //Console.ReadLine();


            Studetn ali = new Studetn(); 
            
        }
    }
}
